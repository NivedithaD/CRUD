package com.example.demo;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class StudentController {
	
@Autowired
StudentService ss;

@RequestMapping(value="/students")
public  ModelAndView students(Model model,Student student) {
	
	ModelAndView mv = new ModelAndView();
	
	mv.addObject("students", ss.getAllStudents());
	mv.setViewName("students");
	return mv;
}

@RequestMapping(value="/student")
public ModelAndView add(Student student){
	return new ModelAndView("addStudents");
}

@RequestMapping(value="/students", method = RequestMethod.POST)
public ModelAndView addstudents(@Valid Student student, BindingResult result){
	ModelAndView model = new ModelAndView();
	StudentService.addStudent(student);
	return new ModelAndView("addstudents");
}

}

/*@RequestMapping("/students")
public List<Student>getAllStudents(){
	return studentService.getAllStudents();
}
*/
/*@RequestMapping("/students/{id}")
public Student getStudent(@PathVariable Long id){
	return studentService.getStudent(id);
	}

@RequestMapping(method=RequestMethod.POST,value="/students")
public void addStudent(@RequestBody Student student){
	studentService.addStudent(student);
}

@RequestMapping(method=RequestMethod.PUT,value="/students/{id}")
	public void updateStudent(@RequestBody Student student,@PathVariable Long id){
		studentService.updateStudent(id,student);
	
}

	@RequestMapping(method=RequestMethod.DELETE,value="/students/{id}")
		public void deleteStudent(@RequestBody Student student,@PathVariable Long id){
			studentService.deleteStudent(id);
}*/
	
