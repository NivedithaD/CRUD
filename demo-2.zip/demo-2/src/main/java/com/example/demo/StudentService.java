package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class StudentService {
private static List<Student> students = new ArrayList<>(Arrays.asList(
		new Student(1,"Niveditha","Java"),
		new Student(2,"Harsha","Electronics"),
		new Student(3,"Chaitanya","Reliability")
		));
public List<Student> getAllStudents(){
	return students;
}

public static void addStudent(Student student){
	students.add(student);
}
}

/*public Student getStudent(Long id) {
	
	return students.stream().filter(t -> t.getId().equals(id)).findFirst().get();
}


public void updateStudent(Long id, Student student) {
	for(int i=0;i<students.size();i++)
	{
		Student s = students.get(i);
		if(s.getId().equals(id)){
			students.set(i, student);
			return;
		
		}
	}
}
public void deleteStudent(Long id){
	students.removeIf(t->t.getId().equals(id));
}

}
*/